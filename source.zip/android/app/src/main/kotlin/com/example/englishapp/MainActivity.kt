package com.example.englishapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
