package com.tady0857.englishapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
